export const baseUrl = `${process.env.REACT_APP_JSON_SERVER_BASE_URL}`;
